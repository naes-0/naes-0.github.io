ERGO 1.0 — Windows x64

Запуск: ERGO.exe
Установка и подключение к интернету не требуются.

Игра создана на Godot 4.7.
Лицензия шрифта M PLUS Rounded 1c находится в OFL-MPLUSRounded1c.txt.
